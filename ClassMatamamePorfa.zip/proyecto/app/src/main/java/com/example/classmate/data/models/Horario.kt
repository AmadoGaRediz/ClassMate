package com.example.classmate.data.models

data class Horario(
    val id: String = "",
    val materia: String = "",
    val hora_inicio: String = "",
    val hora_fin: String = "",
    val profesor: String = "",
    val dia: String = ""
)