package com.example.classmate.data.models

data class Examen(
    val id: String = "",
    val materia: String = "",
    val notification: Boolean = false,
    val dueDate: String = "",
    val reminder: String = "",
    val temas: String = ""
)